import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Wallet, Swords, Trophy, Settings } from 'lucide-react';

const NAV_ITEMS = [
  { path: '/Dashboard', icon: LayoutDashboard, label: 'Home' },
  { path: '/Budget', icon: Wallet, label: 'Budget' },
  { path: '/Challenges', icon: Swords, label: 'Clash' },
  { path: '/Badges', icon: Trophy, label: 'Badges' },
  { path: '/Settings', icon: Settings, label: 'Settings' },
];

export default function MobileNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 px-2 py-1 safe-area-bottom">
      <div className="flex items-center justify-around">
        {NAV_ITEMS.map(item => {
          const isActive = location.pathname === item.path;
          return (
            <Link key={item.path} to={item.path} className="flex flex-col items-center py-2 px-3">
              <item.icon className={`w-5 h-5 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
              <span className={`text-[10px] mt-1 ${isActive ? 'text-primary font-semibold' : 'text-muted-foreground'}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}