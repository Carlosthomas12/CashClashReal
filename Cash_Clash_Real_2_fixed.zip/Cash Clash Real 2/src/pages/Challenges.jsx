import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Swords, Plus, Trophy, Clock, CheckCircle, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { format, startOfWeek, endOfWeek, addDays } from 'date-fns';

export default function Challenges() {
  const [user, setUser] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ title: '', opponent_email: '', opponent_name: '', savings_goal: '' });
  const queryClient = useQueryClient();

  useEffect(() => { base44.auth.me().then(setUser); }, []);

  const { data: challenges } = useQuery({
    queryKey: ['challenges'],
    queryFn: () => base44.entities.Challenge.list('-created_date', 50),
    enabled: !!user,
    initialData: [],
  });

  const myChallenges = challenges.filter(c => 
    c.challenger_email === user?.email || c.opponent_email === user?.email
  );

  const handleCreate = async () => {
    const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
    const weekEnd = endOfWeek(new Date(), { weekStartsOn: 1 });

    await base44.entities.Challenge.create({
      ...form,
      savings_goal: parseFloat(form.savings_goal),
      challenger_email: user.email,
      challenger_name: user.full_name,
      week_start: format(weekStart, 'yyyy-MM-dd'),
      week_end: format(weekEnd, 'yyyy-MM-dd'),
      challenger_savings: 0,
      opponent_savings: 0,
      status: 'pending',
    });
    queryClient.invalidateQueries({ queryKey: ['challenges'] });
    setDialogOpen(false);
    setForm({ title: '', opponent_email: '', opponent_name: '', savings_goal: '' });
    toast.success('Challenge sent!');
  };

  const handleAccept = async (challenge) => {
    await base44.entities.Challenge.update(challenge.id, { status: 'active' });
    queryClient.invalidateQueries({ queryKey: ['challenges'] });
    toast.success('Challenge accepted! Game on!');
  };

  const getStatusBadge = (status) => {
    const styles = {
      pending: 'bg-chart-3/10 text-chart-3 border-chart-3/20',
      active: 'bg-primary/10 text-primary border-primary/20',
      completed: 'bg-accent/10 text-accent border-accent/20',
    };
    return <Badge variant="outline" className={styles[status]}>{status}</Badge>;
  };

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-heading font-bold flex items-center gap-2">
            <Swords className="w-6 h-6 text-accent" /> 1v1 Clash
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Challenge friends to weekly savings battles</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-2"><Plus className="w-4 h-4" /> New Challenge</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-heading">Create a Clash</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div>
                <Label className="text-xs">Challenge Title</Label>
                <Input placeholder="e.g. No Eating Out Week" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Opponent's Name</Label>
                  <Input placeholder="Friend's name" value={form.opponent_name} onChange={e => setForm({ ...form, opponent_name: e.target.value })} />
                </div>
                <div>
                  <Label className="text-xs">Opponent's Email</Label>
                  <Input type="email" placeholder="friend@email.com" value={form.opponent_email} onChange={e => setForm({ ...form, opponent_email: e.target.value })} />
                </div>
              </div>
              <div>
                <Label className="text-xs">Weekly Savings Goal ($)</Label>
                <Input type="number" placeholder="e.g. 50" value={form.savings_goal} onChange={e => setForm({ ...form, savings_goal: e.target.value })} />
              </div>
              <Button onClick={handleCreate} className="w-full gap-2">
                <Swords className="w-4 h-4" /> Send Challenge
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Active Challenges */}
      {myChallenges.length === 0 ? (
        <Card className="p-12 text-center">
          <Swords className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-lg font-heading font-semibold">No challenges yet</p>
          <p className="text-sm text-muted-foreground mt-1">Create a 1v1 challenge and compete with friends!</p>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {myChallenges.map((ch, i) => {
            const isChallenger = ch.challenger_email === user?.email;
            const isPending = ch.status === 'pending' && !isChallenger;
            return (
              <motion.div key={ch.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Card className="overflow-hidden">
                  <CardHeader className="pb-3 flex flex-row items-start justify-between">
                    <div>
                      <CardTitle className="text-base font-heading">{ch.title}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-1">
                        {ch.week_start && ch.week_end && `${format(new Date(ch.week_start), 'MMM d')} - ${format(new Date(ch.week_end), 'MMM d')}`}
                      </p>
                    </div>
                    {getStatusBadge(ch.status)}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* VS Display */}
                    <div className="flex items-center justify-between bg-muted/50 rounded-xl p-4">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">{ch.challenger_name}</p>
                        <p className="text-xl font-heading font-bold mt-1">${ch.challenger_savings || 0}</p>
                      </div>
                      <div className="px-3">
                        <span className="text-xs font-bold text-muted-foreground bg-background px-3 py-1 rounded-full">VS</span>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">{ch.opponent_name || 'Opponent'}</p>
                        <p className="text-xl font-heading font-bold mt-1">${ch.opponent_savings || 0}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground flex items-center gap-1">
                        <Target className="w-3 h-3" /> Goal: ${ch.savings_goal}
                      </span>
                      {isPending && (
                        <Button size="sm" onClick={() => handleAccept(ch)} className="gap-1">
                          <CheckCircle className="w-3 h-3" /> Accept
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}